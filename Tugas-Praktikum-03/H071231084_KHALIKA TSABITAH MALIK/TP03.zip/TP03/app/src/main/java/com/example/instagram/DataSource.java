package com.example.instagram;

import android.util.Log;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import com.example.instagram.models.Highlight;
import com.example.instagram.models.Post;
import com.example.instagram.models.User;

public class DataSource {

    public static ArrayList<User> users;
    public static ArrayList<Post> posts;
    public static ArrayList<Highlight> highlights;
    public static Map<User, ArrayList<Post>> userPosts = new HashMap<>();
    public static Map<User, ArrayList<Highlight>> userHighlights = new HashMap<>();

    // User instance
    public static User me, art1, art2, amel, ghibli, sic, magal;

    public static void init() {
        users = generateDummyUsers();
        userPosts = generateUserPosts();
        posts = collectAllPosts();
        highlights = generateDummyHighlights();
        userHighlights = generateUserHighlights();
    }

    private static ArrayList<User> generateDummyUsers() {
        me = new User("terkayang", "sucipto goreng", R.drawable.pp_sucipto, "hidup seperti larry", 229, 204);
        art1 = new User("xc_aes", "ariety", R.drawable.pp_art, "i love art", 100, 20);
        art2 = new User("sea_cx", "ietyra", R.drawable.pp_art2, "i draw everyday", 231, 156);
        amel = new User("itsandani", "Amelia Andani", R.drawable.pp_amel, "bright smile and vibrancy✨", 2000, 700);
        ghibli = new User("ghibli_gangs", "Ghibli Studio's Best Chara", R.drawable.pp_ghibli, "yang ghibli ghibli aja", 5000, 600);
        sic = new User("sicduatiga", "Sistem Informasi Cerdas 2023", R.drawable.pp_sic, "orang cerdas pilih sic", 98, 50);
        magal = new User("magal_archive", "Archive of Our Friendship", R.drawable.pp_magal, "since 2017 until forever", 213, 201);

        ArrayList<User> users = new ArrayList<>();
        users.add(me);
        users.add(art1);
        users.add(art2);
        users.add(amel);
        users.add(ghibli);
        users.add(sic);
        users.add(magal);

        return users;
    }

    private static Map<User, ArrayList<Post>> generateUserPosts() {
        addPost(me, new Post(R.drawable.post_meme1, "pls", me, getRandomLike(), getRandomComment()));
        addPost(me, new Post(R.drawable.post_meme2, "yeah", me, getRandomLike(), getRandomComment()));
        addPost(me, new Post(R.drawable.post_meme3, "srius??", me, getRandomLike(), getRandomComment()));
        addPost(me, new Post(R.drawable.post_meme4, "owaLach", me, getRandomLike(), getRandomComment()));
        addPost(me, new Post(R.drawable.post_meme5, "pft", me, getRandomLike(), getRandomComment()));
        addPost(me, new Post(R.drawable.post_meme6, "awikwok", me, getRandomLike(), getRandomComment()));

        addPost(amel, new Post(R.drawable.post_amel1, "love this cafe", amel, getRandomLike(), getRandomComment()));
        addPost(amel, new Post(R.drawable.post_amel2, "it smells nice <3", amel, getRandomLike(), getRandomComment()));

        addPost(art1, new Post(R.drawable.post_art1, "first post!", art1, getRandomLike(), getRandomComment()));
        addPost(art1, new Post(R.drawable.post_art2, "second post!", art1, getRandomLike(), getRandomComment()));
        addPost(art1, new Post(R.drawable.post_art3, "third post!", art1, getRandomLike(), getRandomComment()));

        addPost(art2, new Post(R.drawable.post_art4, "my first art", art2, getRandomLike(), getRandomComment()));

        addPost(ghibli, new Post(R.drawable.post_ghibli1, "ponyo", ghibli, getRandomLike(), getRandomComment()));
        addPost(ghibli, new Post(R.drawable.post_ghibli2, "cika", ghibli, getRandomLike(), getRandomComment()));
        addPost(ghibli, new Post(R.drawable.post_ghibli3, "nur", ghibli, getRandomLike(), getRandomComment()));
        addPost(ghibli, new Post(R.drawable.post_ghibli4, "ariety", ghibli, getRandomLike(), getRandomComment()));
        addPost(ghibli, new Post(R.drawable.post_ghibli5, "davi", ghibli, getRandomLike(), getRandomComment()));
        addPost(ghibli, new Post(R.drawable.post_ghibli6, "acil", ghibli, getRandomLike(), getRandomComment()));

        addPost(sic, new Post(R.drawable.post_sic1, "finally ada foto bersama", sic, getRandomLike(), getRandomComment()));

        addPost(magal, new Post(R.drawable.post_magal1, "ini difotoin nabila", magal, getRandomLike(), getRandomComment()));
        addPost(magal, new Post(R.drawable.post_magal2, "ini difotoin pelor", magal, getRandomLike(), getRandomComment()));

        Log.d("DataSource", "UserPosts size: " + userPosts.size());

        return userPosts;
    }

    private static ArrayList<Post> collectAllPosts() {
        ArrayList<Post> allPosts = new ArrayList<>();
        for (ArrayList<Post> postList : userPosts.values()) {
            allPosts.addAll(postList);
        }

        // Mengacak urutan posts
        Collections.shuffle(allPosts);
        return allPosts;
    }

//    private static ArrayList<Highlight> generateDummyHighlights() {
//        ArrayList<Highlight> highlights = new ArrayList<>();
//
//        return highlights;
//    }


    private static ArrayList<Highlight> generateDummyHighlights() {
        ArrayList<Highlight> highlights = new ArrayList<>();

        // Highlights for me
        ArrayList<Integer> myHighlightImages1 = new ArrayList<>();
        myHighlightImages1.add(R.drawable.hl_tungtung);
        highlights.add(new Highlight("tungtung", R.drawable.hl_tungtung, myHighlightImages1, me));

        ArrayList<Integer> myHighlightImages2 = new ArrayList<>();
        myHighlightImages2.add(R.drawable.hl_citi);
        highlights.add(new Highlight("velositi", R.drawable.hl_citi, myHighlightImages2, me));

        ArrayList<Integer> myHighlightImages3 = new ArrayList<>();
        myHighlightImages3.add(R.drawable.hl_crocodilo);
        highlights.add(new Highlight("crocodilo", R.drawable.hl_crocodilo, myHighlightImages3, me));

        ArrayList<Integer> myHighlightImages4 = new ArrayList<>();
        myHighlightImages4.add(R.drawable.hl_gararam);
        highlights.add(new Highlight("gararam", R.drawable.hl_gararam, myHighlightImages4, me));

        ArrayList<Integer> myHighlightImages5 = new ArrayList<>();
        myHighlightImages5.add(R.drawable.hl_goriraro);
        highlights.add(new Highlight("goriraro", R.drawable.hl_goriraro, myHighlightImages5, me));

        ArrayList<Integer> myHighlightImages6 = new ArrayList<>();
        myHighlightImages6.add(R.drawable.hl_tralala);
        highlights.add(new Highlight("tralala", R.drawable.hl_tralala, myHighlightImages6, me));

        ArrayList<Integer> myHighlightImages7 = new ArrayList<>();
        myHighlightImages7.add(R.drawable.hl_tralalero);
        highlights.add(new Highlight("tralalero", R.drawable.hl_tralalero, myHighlightImages7, me));

        // Highlights for art1
        ArrayList<Integer> art1HighlightImages = new ArrayList<>();
        art1HighlightImages.add(R.drawable.post_art1);
        art1HighlightImages.add(R.drawable.post_art2);
        art1HighlightImages.add(R.drawable.post_art3);
        highlights.add(new Highlight("a r t", R.drawable.post_art1, art1HighlightImages, art1));

        // Highlights for art1
        ArrayList<Integer> art2HighlightImages = new ArrayList<>();
        art2HighlightImages.add(R.drawable.post_art4);
        highlights.add(new Highlight("aruto", R.drawable.post_art4, art1HighlightImages, art1));

        // Highlights for amel
        ArrayList<Integer> amelHighlightImages = new ArrayList<>();
        amelHighlightImages.add(R.drawable.hl_amel1);
        amelHighlightImages.add(R.drawable.hl_amel2);
        amelHighlightImages.add(R.drawable.hl_amel3);
        highlights.add(new Highlight("me", R.drawable.hl_amel1, amelHighlightImages, amel));

        // Highlights for ghibli
        ArrayList<Integer> ghibliHighlightImages1 = new ArrayList<>();
        ghibliHighlightImages1.add(R.drawable.post_ghibli1);
        ghibliHighlightImages1.add(R.drawable.post_ghibli2);
        ghibliHighlightImages1.add(R.drawable.post_ghibli3);
        ghibliHighlightImages1.add(R.drawable.post_ghibli4);
        highlights.add(new Highlight("onna", R.drawable.post_ghibli1, ghibliHighlightImages1, ghibli));

        ArrayList<Integer> ghibliHighlightImages2 = new ArrayList<>();
        ghibliHighlightImages2.add(R.drawable.post_ghibli5);
        ghibliHighlightImages2.add(R.drawable.post_ghibli6);
        highlights.add(new Highlight("otoko", R.drawable.post_ghibli5, ghibliHighlightImages2, ghibli));

        // Highlights for sic
        ArrayList<Integer> sicHighlightImages = new ArrayList<>();
        sicHighlightImages.add(R.drawable.hl_sic);
        highlights.add(new Highlight("highlight", R.drawable.hl_sic, sicHighlightImages, sic));

        // Highlights for magal
        ArrayList<Integer> magalHighlightImages = new ArrayList<>();
        magalHighlightImages.add(R.drawable.hl_magal1);
        magalHighlightImages.add(R.drawable.hl_magal2);
        highlights.add(new Highlight("moments", R.drawable.hl_magal1, magalHighlightImages, magal));

        return highlights;
    }

    private static Map<User, ArrayList<Highlight>> generateUserHighlights() {
        Map<User, ArrayList<Highlight>> userHighlightsMap = new HashMap<>();

        for (Highlight highlight : highlights) {
            User user = highlight.getUser();
            userHighlightsMap.computeIfAbsent(user, k -> new ArrayList<>()).add(highlight);
        }

        return userHighlightsMap;
    }


    private static int getRandomLike() {
        return (int) (Math.random() * (5000 - 1000) + 1000);
    }

    private static int getRandomComment() {
        return (int) (Math.random() * (300 - 10) + 10);
    }

    private static void addPost(User user, Post post) {
        userPosts.computeIfAbsent(user, k ->
                new ArrayList<>()).add(0, post);
    }

    public static void addNewPost(Post newPost) {
        posts.add(0, newPost);
        addPost(newPost.getUser(), newPost);
    }
}
