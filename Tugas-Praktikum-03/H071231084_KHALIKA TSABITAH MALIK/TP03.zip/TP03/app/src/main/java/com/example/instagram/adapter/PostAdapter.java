package com.example.instagram.adapter;

import android.content.Intent;
import android.net.Uri;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.instagram.DataSource;
import com.example.instagram.ProfileActivity;
import com.example.instagram.R;
import com.example.instagram.models.Post;

import java.util.ArrayList;

public class PostAdapter extends RecyclerView.Adapter<PostAdapter.ViewHolder> {
    private ArrayList<Post> posts;

//    constructor
    public PostAdapter(ArrayList<Post> posts) {
        this.posts = posts;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.post_item, parent, false);

        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Post post = posts.get(position);

        holder.tvUsername.setText(post.getUser().getUsername());
        holder.tvCaption.setText(post.getCaption());
        holder.tvLikesCount.setText(String.valueOf(post.getLikeCount()));
        holder.tvCommentsCount.setText(String.valueOf(post.getCommentCount()));
        holder.tvUsnCaption.setText(post.getUser().getUsername());
        holder.ivProfileImage.setImageResource(post.getUser().getProfileImage());

        Object image = post.isFromUri() ? Uri.parse(post.getImageUri()) : post.getImagePost();
        Glide.with(holder.itemView.getContext()).load(image).into(holder.ivPostImage);


        holder.profileInfo.setOnClickListener(v -> {
            Intent intent = new Intent(holder.itemView.getContext(), ProfileActivity.class);
            boolean myAccount;
            if (post.getUser().equals(DataSource.me)) {
                myAccount = true;
            } else {
                myAccount = false;
            }
            intent.putExtra("myAccount", myAccount);
            intent.putExtra("user", post.getUser());
            holder.itemView.getContext().startActivity(intent);
        });
    }

    @Override
    public int getItemCount() {
        return posts.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        private TextView tvUsername, tvCaption, tvLikesCount, tvCommentsCount, tvUsnCaption, tvStoryUsername;
        private ImageView ivProfileImage, ivPostImage;
        private LinearLayout profileInfo;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            tvUsername = itemView.findViewById(R.id.tvUsername);
            tvCaption = itemView.findViewById(R.id.tvCaption);
            tvLikesCount = itemView.findViewById(R.id.tvLikesCount);
            tvCommentsCount = itemView.findViewById(R.id.tvCommentsCount);
            tvUsnCaption = itemView.findViewById(R.id.tvUsnCapt);
            ivProfileImage = itemView.findViewById(R.id.profileImage);
            ivPostImage = itemView.findViewById(R.id.imagePost);
            profileInfo = itemView.findViewById(R.id.profileInfo);
        }
    }
}
