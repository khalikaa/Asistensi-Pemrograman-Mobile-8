package com.example.instagram.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.instagram.R;
import com.example.instagram.models.Highlight;

import java.util.ArrayList;

public class HighlightIconAdapter extends RecyclerView.Adapter<HighlightIconAdapter.ViewHolder> {

    private final ArrayList<Highlight> highlights;
    private final Context context;
    private final OnHighlightClickListener listener;

    public interface OnHighlightClickListener {
        void onHighlightClick(Highlight highlight, int position);
    }

    public HighlightIconAdapter(Context context, ArrayList<Highlight> highlights, OnHighlightClickListener listener) {
        this.context = context;
        this.highlights = highlights;
        this.listener = listener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.story_item, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Highlight highlight = highlights.get(position);

        // Set the cover image (first image from the list)
        holder.imgHighlightIcon.setImageResource(highlight.getImageIcon());

        // Set the title
        holder.tvHighlightTitle.setText(highlight.getHlTitle());

        // Set click listener
        holder.itemView.setOnClickListener(v -> {
            if (listener != null) {
                listener.onHighlightClick(highlight, position);
            }
        });
    }

    @Override
    public int getItemCount() {
        return highlights.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        ImageView imgHighlightIcon;
        TextView tvHighlightTitle;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            imgHighlightIcon = itemView.findViewById(R.id.image);
            tvHighlightTitle = itemView.findViewById(R.id.tvTitle);
        }
    }
}