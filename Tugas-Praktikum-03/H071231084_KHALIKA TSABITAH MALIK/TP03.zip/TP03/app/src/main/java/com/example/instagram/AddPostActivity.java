package com.example.instagram;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.example.instagram.models.Post;
import com.example.instagram.models.User;

import de.hdodenhof.circleimageview.CircleImageView;

public class AddPostActivity extends AppCompatActivity {

    private ImageView ivPostImage;
    private Button btnChoosePhoto, btnPost;
    private EditText etCaption;
    private Uri selectedImageUri;
    private boolean photoSelected = false;
    private CircleImageView profileImage;
    private ImageView btnHomePage;

    private final ActivityResultLauncher<String> galleryLauncher = registerForActivityResult(
            new ActivityResultContracts.GetContent(),
            uri -> {
                if (uri != null) {
                    selectedImageUri = uri;
                    photoSelected = true;
                    ivPostImage.setImageURI(uri);
                }
            }
    );

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_post);

        ivPostImage = findViewById(R.id.ivPhoto);
        btnChoosePhoto = findViewById(R.id.btnChoose);
        btnPost = findViewById(R.id.btnPost);
        etCaption = findViewById(R.id.etCaption);
        profileImage = findViewById(R.id.profileImage);
        btnHomePage = findViewById(R.id.btnHomePage);

        btnChoosePhoto.setOnClickListener(v -> {
            galleryLauncher.launch("image/*");
        });

        btnHomePage.setOnClickListener(v -> {
            Intent intent = new Intent(this, MainActivity.class);
            startActivity(intent);
        });

        profileImage.setOnClickListener(v -> {
            Intent intent = new Intent(this, ProfileActivity.class);
            intent.putExtra("myAccount", true);
            startActivity(intent);
        });

        btnPost.setOnClickListener(v -> {
            if (!photoSelected) {
                Toast.makeText(this, "Please select a photo first", Toast.LENGTH_SHORT).show();
                return;
            }

            String caption = etCaption.getText().toString().trim();

            if (caption.isEmpty()) {
                Toast.makeText(this, "Please enter a caption", Toast.LENGTH_SHORT).show();
                return;
            }

            User me = DataSource.me;

            Post newPost = new Post(-1, caption, me, 0, 0);
            newPost.setImageUri(selectedImageUri.toString());

            DataSource.addNewPost(newPost);

            Toast.makeText(this, "Post created successfully!", Toast.LENGTH_SHORT).show();

            Intent intent = new Intent(this, MainActivity.class);
            startActivity(intent);
        });


    }
}