package com.example.instagram.models;

import android.os.Parcel;
import android.os.Parcelable;

import androidx.annotation.NonNull;

public class Post implements Parcelable {
    private int imagePost;
    private String imageUri;
    private String caption;
    private User user;
    private int likeCount;
    private int commentCount;

    public Post(int imagePost, String caption, User user, int likeCount, int commentCount) {
        this.imagePost = imagePost;
        this.caption = caption;
        this.user = user;
        this.likeCount = likeCount;
        this.commentCount = commentCount;
    }

    protected Post(Parcel in) {
        imagePost = in.readInt();
        imageUri = in.readString();
        caption = in.readString();
        user = in.readParcelable(User.class.getClassLoader());
        likeCount = in.readInt();
        commentCount = in.readInt();
    }

    public static final Creator<Post> CREATOR = new Creator<Post>() {
        @Override
        public Post createFromParcel(Parcel in) {
            return new Post(in);
        }

        @Override
        public Post[] newArray(int size) {
            return new Post[size];
        }
    };

    public int getImagePost() {
        return imagePost;
    }

    public void setImagePost(int imagePost) {
        this.imagePost = imagePost;
    }

    public String getCaption() {
        return caption;
    }

    public void setCaption(String caption) {
        this.caption = caption;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public int getLikeCount() {
        return likeCount;
    }

    public void setLikeCount(int likeCount) {
        this.likeCount = likeCount;
    }

    public int getCommentCount() {
        return commentCount;
    }

    public void setCommentCount(int commentCount) {
        this.commentCount = commentCount;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(@NonNull Parcel parcel, int flags) {
        parcel.writeInt(imagePost);
        parcel.writeString(imageUri);
        parcel.writeString(caption);
        parcel.writeParcelable(user, flags);
        parcel.writeInt(likeCount);
        parcel.writeInt(commentCount);
    }

    public String getImageUri() {
        return imageUri;
    }

    public void setImageUri(String imageUri) {
        this.imageUri = imageUri;
    }

    public boolean isFromUri() {
        return (imageUri != null);
    }
}
