package com.example.instagram.models;

import android.os.Parcel;
import android.os.Parcelable;
import androidx.annotation.NonNull;
import java.util.ArrayList;
import java.util.List;

public class Highlight implements Parcelable {
    private String hlTitle;
    private int imageIcon;
    private List<Integer> imageHighlights;
    private User user;

    public Highlight(String hlTitle, int imageIcon, List<Integer> imageHighlights, User user) {
        this.hlTitle = hlTitle;
        this.imageIcon = imageIcon;
        this.imageHighlights = imageHighlights;
        this.user = user;
    }

    protected Highlight(Parcel in) {
        hlTitle = in.readString();
        imageIcon = in.readInt();
        imageHighlights = new ArrayList<>();
        in.readList(imageHighlights, Integer.class.getClassLoader());
        user = in.readParcelable(User.class.getClassLoader());
    }

    public static final Creator<Highlight> CREATOR = new Creator<Highlight>() {
        @Override
        public Highlight createFromParcel(Parcel in) {
            return new Highlight(in);
        }

        @Override
        public Highlight[] newArray(int size) {
            return new Highlight[size];
        }
    };

    public String getHlTitle() {
        return hlTitle;
    }

    public void setHlTitle(String hlTitle) {
        this.hlTitle = hlTitle;
    }

    public List<Integer> getImageHighlights() {
        return imageHighlights;
    }

    public void setImageHighlights(List<Integer> imageHighlights) {
        this.imageHighlights = imageHighlights;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public int getImageIcon() {
        return imageIcon;
    }

    public void setImageIcon(int imageIcon) {
        this.imageIcon = imageIcon;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(@NonNull Parcel parcel, int i) {
        parcel.writeString(hlTitle);
        parcel.writeInt(imageIcon);
        parcel.writeList(imageHighlights);
        parcel.writeParcelable(user, i);
    }
}