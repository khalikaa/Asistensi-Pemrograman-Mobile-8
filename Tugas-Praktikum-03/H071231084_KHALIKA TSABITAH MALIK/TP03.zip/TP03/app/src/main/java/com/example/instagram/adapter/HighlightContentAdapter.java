package com.example.instagram.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.instagram.R;
import java.util.List;

public class HighlightContentAdapter extends RecyclerView.Adapter<HighlightContentAdapter.ViewHolder> {

    private final List<Integer> imageResIds;
    private final Context context;

    public HighlightContentAdapter(Context context, List<Integer> imageResIds) {
        this.context = context;
        this.imageResIds = imageResIds;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.highlight_item, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        int imageResId = imageResIds.get(position);
        holder.ivBackGroundBlur.setImageResource(imageResId);
        holder.ivMainImage.setImageResource(imageResId);
    }

    @Override
    public int getItemCount() {
        return imageResIds.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        ImageView ivBackGroundBlur, ivMainImage;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            ivBackGroundBlur = itemView.findViewById(R.id.ivBackgroundBlur);
            ivMainImage= itemView.findViewById(R.id.ivMainImage);
        }
    }
}