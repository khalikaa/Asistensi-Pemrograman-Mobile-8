package com.example.instagram.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.instagram.R;
import com.example.instagram.models.User;

import java.util.ArrayList;

public class StoryAdapter extends RecyclerView.Adapter<StoryAdapter.ViewHolder> {
    ArrayList<User> users;

    public StoryAdapter(ArrayList<User> users) {
        this.users = users;
    }

    @NonNull
    @Override
    public StoryAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.story_item, parent, false);

        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull StoryAdapter.ViewHolder holder, int position) {
        User user = users.get(position);
        holder.tvStoryUsername.setText(user.getUsername());
        holder.ivStoryProfile.setImageResource(user.getProfileImage());
    }

    @Override
    public int getItemCount() {
        return users.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        private TextView tvStoryUsername;
        private ImageView ivStoryProfile;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            tvStoryUsername = itemView.findViewById(R.id.tvTitle);
            ivStoryProfile = itemView.findViewById(R.id.image);
        }
    }
}
