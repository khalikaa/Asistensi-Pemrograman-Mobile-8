package com.example.instagram.models;

import android.os.Parcel;
import android.os.Parcelable;

import androidx.annotation.NonNull;

import java.util.Objects;

public class User implements Parcelable {
    private String username;
    private String fullName;
    private int profileImage;
    private String bio;
    private int followersCount;
    private int followingCount;

    // Constructor, getter, setter
    public User(String username, String fullName, int profileImage, String bio, int followersCount, int followingCount) {
        this.username = username;
        this.fullName = fullName;
        this.profileImage = profileImage;
        this.bio = bio;
        this.followersCount = followersCount;
        this.followingCount = followingCount;
    }

    protected User(Parcel in) {
        username = in.readString();
        fullName = in.readString();
        profileImage = in.readInt();
        bio = in.readString();
        followersCount = in.readInt();
        followingCount = in.readInt();
    }

    public static final Creator<User> CREATOR = new Creator<User>() {
        @Override
        public User createFromParcel(Parcel in) {
            return new User(in);
        }

        @Override
        public User[] newArray(int size) {
            return new User[size];
        }
    };

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public int getProfileImage() {
        return profileImage;
    }

    public void setProfileImage(int profileImage) {
        this.profileImage = profileImage;
    }

    public String getBio() {
        return bio;
    }

    public void setBio(String bio) {
        this.bio = bio;
    }

    public int getFollowersCount() {
        return followersCount;
    }

    public void setFollowersCount(int followersCount) {
        this.followersCount = followersCount;
    }

    public int getFollowingCount() {
        return followingCount;
    }

    public void setFollowingCount(int followingCount) {
        this.followingCount = followingCount;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        User user = (User) obj;
        return username.equals(user.username);
    }

    @Override
    public int hashCode() {
        return Objects.hash(username);
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(@NonNull Parcel parcel, int i) {
        parcel.writeString(username);
        parcel.writeString(fullName);
        parcel.writeInt(profileImage);
        parcel.writeString(bio);
        parcel.writeInt(followersCount);
        parcel.writeInt(followingCount);
    }
}
