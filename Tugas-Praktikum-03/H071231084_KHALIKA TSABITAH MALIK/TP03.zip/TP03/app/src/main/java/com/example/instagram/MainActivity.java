package com.example.instagram;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.ImageView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.instagram.adapter.PostAdapter;
import com.example.instagram.adapter.StoryAdapter;
import com.example.instagram.models.Post;

import java.util.ArrayList;
import java.util.Collections;

import de.hdodenhof.circleimageview.CircleImageView;

public class MainActivity extends AppCompatActivity {

    private RecyclerView rvPost, rvStory;
    CircleImageView iconProfile;
    ImageView btnPostPage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        rvPost = findViewById(R.id.rv_post);
        rvStory = findViewById(R.id.rv_story);
        iconProfile = findViewById(R.id.iconProfile);

        rvPost.setLayoutManager(new LinearLayoutManager(this));
        rvStory.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false));

//        generate data dummy
        if (DataSource.posts == null || DataSource.posts.isEmpty()) {
            DataSource.init();
        }

        PostAdapter adapter = new PostAdapter(DataSource.posts);
        rvPost.setAdapter(adapter);

        StoryAdapter storyAdapter = new StoryAdapter(DataSource.users);
        rvStory.setAdapter(storyAdapter);

        iconProfile.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, ProfileActivity.class);
            boolean myAccount = true;
            intent.putExtra("myAccount", myAccount);
            startActivity(intent);
        });

        btnPostPage = findViewById(R.id.btnPostPage);
        btnPostPage.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, AddPostActivity.class);
            startActivity(intent);
        });

        }

    @Override
    protected void onResume() {
        super.onResume();
        PostAdapter adapter = new PostAdapter(DataSource.posts);
        rvPost.setAdapter(adapter);
    }

}
