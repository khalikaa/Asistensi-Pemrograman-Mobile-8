package com.example.instagram;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager2.widget.ViewPager2;

import com.example.instagram.adapter.HighlightContentAdapter;
import com.example.instagram.models.Highlight;
import com.google.android.material.tabs.TabLayout;
import com.google.android.material.tabs.TabLayoutMediator;

import java.util.List;

import de.hdodenhof.circleimageview.CircleImageView;

public class HighlightViewActivity extends AppCompatActivity {

    private ViewPager2 viewPager;
    private TextView tvHighlightTitle;
    private CircleImageView profileImage;
    private LinearLayout progressContainer, highlightBottom;
    private TabLayout tabLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_highlight_view);

        initViews();

        Highlight highlight = getIntent().getParcelableExtra("highlight");

        if (highlight != null) {
            setupUI(highlight);
        } else {
            finish();
        }
    }

    private void initViews() {
        viewPager = findViewById(R.id.viewPager);
        tvHighlightTitle = findViewById(R.id.tv_highlight_title);
        profileImage = findViewById(R.id.profile_image);
        progressContainer = findViewById(R.id.progress_container);
        tabLayout = findViewById(R.id.tab_layout);
        highlightBottom = findViewById(R.id.highlightBottom);
    }

    private void setupUI(Highlight highlight) {
        tvHighlightTitle.setText(highlight.getHlTitle());
        profileImage.setImageResource(highlight.getUser().getProfileImage());

        if (highlight.getUser().equals(DataSource.me)) {
            highlightBottom.setVisibility(View.GONE);
        } else {
            highlightBottom.setVisibility(View.VISIBLE);
        }

        List<Integer> images = highlight.getImageHighlights();
        HighlightContentAdapter adapter = new HighlightContentAdapter(this, images);
        viewPager.setAdapter(adapter);

        setupProgressIndicators(images.size());

        new TabLayoutMediator(tabLayout, viewPager, (tab, position) -> {
        }).attach();

        viewPager.registerOnPageChangeCallback(new ViewPager2.OnPageChangeCallback() {
            @Override
            public void onPageSelected(int position) {
                super.onPageSelected(position);
                updateProgressIndicators(position);
            }
        });
    }

    private void setupProgressIndicators(int count) {
        progressContainer.removeAllViews();

        for (int i = 0; i < count; i++) {
            View progressView = LayoutInflater.from(this).inflate(
                    R.layout.highlight_progress, progressContainer, false);

            ProgressBar progressBar = progressView.findViewById(R.id.progress_bar);
            progressBar.setMax(100);

            progressBar.setProgress(i == 0 ? 100 : 0);

            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                    0, LinearLayout.LayoutParams.WRAP_CONTENT, 1.0f);

            if (i > 0) {
                params.setMarginStart(4); // Small gap between indicators
            }

            progressContainer.addView(progressView, params);
        }
    }

    private void updateProgressIndicators(int currentPosition) {
        for (int i = 0; i < progressContainer.getChildCount(); i++) {
            View progressView = progressContainer.getChildAt(i);
            ProgressBar progressBar = progressView.findViewById(R.id.progress_bar);

            progressBar.setProgress(i <= currentPosition ? 100 : 0);
        }
    }
}