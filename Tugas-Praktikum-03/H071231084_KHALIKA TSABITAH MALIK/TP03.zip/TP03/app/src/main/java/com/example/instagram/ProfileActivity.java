package com.example.instagram;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.instagram.adapter.PhotoAdapter;
import com.example.instagram.adapter.HighlightIconAdapter;
import com.example.instagram.adapter.PostAdapter;
import com.example.instagram.models.Highlight;
import com.example.instagram.models.User;
import com.example.instagram.models.Post;

import java.util.ArrayList;

import de.hdodenhof.circleimageview.CircleImageView;

public class ProfileActivity extends AppCompatActivity implements HighlightIconAdapter.OnHighlightClickListener {

    private TextView tvUsnTitle, tvUsnProfile, tvFullName, tvBio;
    private TextView tvPostCount, tvFollowersCount, tvFollowingCount;
    private CircleImageView profileImage;
    private Button btnFirst, btnSecond;
    private ImageView btnPostPage, btnHomePage;
    private User user;
    private RecyclerView rvPhotos;
    private RecyclerView rvHighlights;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_profile);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        initializeViews();

        Intent intent = getIntent();
        boolean myAccount = intent.getBooleanExtra("myAccount", false);

        rvPhotos.setLayoutManager(new GridLayoutManager(this, 3));
        rvHighlights.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false));

        if (myAccount) {
            user = DataSource.me;
            btnFirst.setText("Edit Profile");
            btnSecond.setText("Share Profile");
        } else {
            user = intent.getParcelableExtra("user");
            btnFirst.setText("Following");
            btnSecond.setText("Message");
        }

        ArrayList<Post> userPosts = DataSource.userPosts.get(user);

        updateUserProfileInfo(userPosts);

        if (userPosts != null) {
            PhotoAdapter photoAdapter = new PhotoAdapter(user, userPosts);
            rvPhotos.setAdapter(photoAdapter);
        }

        btnPostPage = findViewById(R.id.btnPostPage);
        btnPostPage.setOnClickListener(v -> {
            Intent newPostintent = new Intent(ProfileActivity.this, AddPostActivity.class);
            startActivity(newPostintent);
        });

        btnHomePage = findViewById(R.id.btnHomePage);
        btnHomePage.setOnClickListener(v -> {
            Intent newPostintent = new Intent(ProfileActivity.this, MainActivity.class);
            startActivity(newPostintent);
        });

        setupHighlights();
    }

    private void initializeViews() {
        tvUsnTitle = findViewById(R.id.tvUsnTitle);
        tvUsnProfile = findViewById(R.id.tvUsnProfile);
        tvFullName = findViewById(R.id.tvFullName);
        tvBio = findViewById(R.id.tvBio);
        tvPostCount = findViewById(R.id.tvPostCount);
        tvFollowersCount = findViewById(R.id.tvFollowersCount);
        tvFollowingCount = findViewById(R.id.tvFollowingCount);
        profileImage = findViewById(R.id.profileImage);
        btnFirst = findViewById(R.id.btnFirst);
        btnSecond = findViewById(R.id.btnSecond);
        rvPhotos = findViewById(R.id.rv_photos);
        rvHighlights = findViewById(R.id.rv_highlight);
    }

    private void updateUserProfileInfo(ArrayList<Post> userPosts) {
        tvUsnTitle.setText(user.getUsername());
        tvUsnProfile.setText(user.getUsername());
        tvFullName.setText(user.getFullName());
        tvBio.setText(user.getBio());
        profileImage.setImageResource(user.getProfileImage());

        tvPostCount.setText(String.valueOf(userPosts != null ? userPosts.size() : 0));
        tvFollowersCount.setText(String.valueOf(user.getFollowersCount()));
        tvFollowingCount.setText(String.valueOf(user.getFollowingCount()));
    }

    private void setupHighlights() {
        ArrayList<Highlight> userHighlights = DataSource.userHighlights.get(user);
        if (userHighlights != null && !userHighlights.isEmpty()) {
            HighlightIconAdapter highlightAdapter = new HighlightIconAdapter(this, userHighlights, this);
            rvHighlights.setAdapter(highlightAdapter);
        } else {
            rvHighlights.setVisibility(android.view.View.GONE);
        }
    }

    @Override
    public void onHighlightClick(Highlight highlight, int position) {
        Intent intent = new Intent(this, HighlightViewActivity.class);
        intent.putExtra("highlight", highlight);
        startActivity(intent);
    }

//    @Override
//    protected void onResume() {
//        super.onResume();
//        ArrayList<Post> userPosts = DataSource.userPosts.get(user);
//        PhotoAdapter adapter = new PhotoAdapter(user, userPosts);
//        rvPhotos.setAdapter(adapter);
//    }


}