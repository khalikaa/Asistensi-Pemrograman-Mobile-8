package com.example.library;

import android.graphics.Color;
import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import com.example.library.databinding.ActivityMainBinding;

public class MainActivity extends AppCompatActivity {

    ActivityMainBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        replaceFragment(new HomeFragment());

        binding.btnHome.setOnClickListener(v -> {
           replaceFragment(new HomeFragment());
           resetButtonStyles();

           binding.btnHome.setBackgroundColor(Color.parseColor("#091732"));
           binding.tvHome.setTextColor(Color.parseColor("#FFFFFF"));
           binding.icHome.setColorFilter(Color.parseColor("#FFFFFF"));
        });

        binding.btnAdd.setOnClickListener(v -> {
            replaceFragment(new AddBookFragment());
            resetButtonStyles();

            binding.btnAdd.setBackgroundColor(Color.parseColor("#091732"));
            binding.tvAdd.setTextColor(Color.parseColor("#FFFFFF"));
            binding.icAdd.setColorFilter(Color.parseColor("#FFFFFF"));
        });

        binding.btnFav.setOnClickListener(v -> {
            replaceFragment(new FavoriteFragment());
            resetButtonStyles();

            binding.btnFav.setBackgroundColor(Color.parseColor("#091732"));
            binding.tvFav.setTextColor(Color.parseColor("#FFFFFF"));
            binding.icFav.setColorFilter(Color.parseColor("#FFFFFF"));
        });

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(binding.main.getId()), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }

    private void replaceFragment(Fragment fragment){
        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
        transaction.replace(binding.fragmentContainer.getId(), fragment);
        transaction.commit();
    }

    private void resetButtonStyles() {
        int bgColor = Color.TRANSPARENT;
        int textColor = Color.parseColor("#97a3c4");
        int iconColor = Color.parseColor("#97a3c4");

        binding.btnHome.setBackgroundColor(bgColor);
        binding.tvHome.setTextColor(textColor);
        binding.icHome.setColorFilter(iconColor);

        binding.btnAdd.setBackgroundColor(bgColor);
        binding.tvAdd.setTextColor(textColor);
        binding.icAdd.setColorFilter(iconColor);

        binding.btnFav.setBackgroundColor(bgColor);
        binding.tvFav.setTextColor(textColor);
        binding.icFav.setColorFilter(iconColor);
    }

}