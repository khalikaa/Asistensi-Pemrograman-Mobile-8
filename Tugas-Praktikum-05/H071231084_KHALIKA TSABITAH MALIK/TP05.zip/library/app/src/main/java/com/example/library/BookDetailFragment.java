package com.example.library;

import android.os.Bundle;
import androidx.fragment.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import com.example.library.databinding.FragmentBookDetailBinding;

public class BookDetailFragment extends Fragment {
    private FragmentBookDetailBinding binding;
    private BookRepository bookRepository;
    private Book book;
    private String bookId;

    public BookDetailFragment() {}

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            bookId = getArguments().getString("book_id");
        }
        bookRepository = BookRepository.getInstance(requireContext());
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        binding = FragmentBookDetailBinding.inflate(inflater, container, false);

        if (bookId != null) {
            book = bookRepository.getBookById(bookId);
            displayBookDetails();
        }

        binding.btnFav.setOnClickListener(v -> {
            if (book != null) {
                bookRepository.toggleLike(book.getId());
                updateFavoriteButton();
            }
        });

        return binding.getRoot();
    }

    private void displayBookDetails() {
        if (book != null) {
            binding.ivBookCover.setImageURI(book.getCoverUri());
            binding.tvTitle.setText(book.getTitle());
            binding.tvAuthor.setText(book.getAuthor());
            binding.tvYear.setText(String.valueOf(book.getPublicationYear()));
            binding.tvGenre.setText(book.getGenre());
            binding.tvBlurb.setText(book.getBlurb());
            binding.tvRating.setText("⭐ " + String.format("%.1f", book.getRating()));

            updateFavoriteButton();
        }
    }

    private void updateFavoriteButton() {
        binding.btnFav.setImageResource(
                book.isLiked() ? R.drawable.ic_fav_red : R.drawable.ic_fav
        );
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}