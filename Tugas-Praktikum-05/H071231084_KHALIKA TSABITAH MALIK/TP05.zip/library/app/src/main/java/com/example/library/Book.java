package com.example.library;

import android.net.Uri;
import java.util.Calendar;
import java.util.Date;

public class Book {
    private String id;
    private String title;
    private String author;
    private int publicationYear;
    private String blurb;
    private Uri coverUri;
    private boolean isLiked;
    private String genre;
    private float rating;
    private Date dateAdded;

    public Book(String id, String title, String author, int publicationYear,
                String blurb, Uri coverUri, boolean isLiked, String genre, float rating) {
        this.id = id;
        this.title = title;
        this.author = author;
        this.publicationYear = publicationYear;
        this.blurb = blurb;
        this.coverUri = coverUri;
        this.isLiked = isLiked;
        this.genre = genre;
        this.rating = rating;
        this.dateAdded = Calendar.getInstance().getTime();
    }

    public String getId() {
        return id;
    }

    public String getTitle() {
        return title;
    }

    public String getAuthor() {
        return author;
    }

    public int getPublicationYear() {
        return publicationYear;
    }

    public String getBlurb() {
        return blurb;
    }

    public Uri getCoverUri() {
        return coverUri;
    }

    public boolean isLiked() {
        return isLiked;
    }

    public String getGenre() {
        return genre;
    }

    public float getRating() {
        return rating;
    }

    public Date getDateAdded() {
        return dateAdded;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public void setPublicationYear(int publicationYear) {
        this.publicationYear = publicationYear;
    }

    public void setBlurb(String blurb) {
        this.blurb = blurb;
    }

    public void setCoverUri(Uri coverUri) {
        this.coverUri = coverUri;
    }

    public void setLiked(boolean liked) {
        isLiked = liked;
    }

    public void setGenre(String genre) {
        this.genre = genre;
    }

    public void setRating(float rating) {
        this.rating = rating;
    }
}