package com.example.library;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.widget.SearchView;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.example.library.databinding.FragmentFavoritesBinding;

import java.util.ArrayList;
import java.util.List;

public class FavoriteFragment extends Fragment implements FavoriteAdapter.OnFavoriteBookListener {

    private FragmentFavoritesBinding binding;
    private BookRepository bookRepository;
    private FavoriteAdapter adapter;
    private List<Book> allFavorites;
    private String currentGenre = "All";
    private String currentQuery = "";
    private final Handler handler = new Handler(Looper.getMainLooper());
    private boolean isFirstLoad = true;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        bookRepository = BookRepository.getInstance(requireContext());
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        binding = FragmentFavoritesBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        setupRecyclerView();
        setupSearchView();
        setupSpinner();

        if (isFirstLoad) {
            binding.progressBar.setVisibility(View.VISIBLE);
            binding.emptyView.setVisibility(View.GONE);
            binding.filterEmptyView.setVisibility(View.GONE);
            binding.rvFavs.setVisibility(View.GONE);
            loadAllFavoriteBooks();
        } else {
            updateUIWithCurrentData();
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        if (!isFirstLoad) {
            allFavorites = bookRepository.getLikedBooks();
            updateUIWithCurrentData();
        }
    }

    private void updateUIWithCurrentData() {
        if (allFavorites == null || allFavorites.isEmpty()) {
            binding.progressBar.setVisibility(View.GONE);
            binding.emptyView.setVisibility(View.VISIBLE);
            binding.filterEmptyView.setVisibility(View.GONE);
            binding.rvFavs.setVisibility(View.GONE);
        } else {
            List<Book> filteredFavorites = new ArrayList<>();

            if (allFavorites != null && !allFavorites.isEmpty()) {
                filteredFavorites = new ArrayList<>(allFavorites);
            }

            if (!currentGenre.equals("All") && !filteredFavorites.isEmpty()) {
                filteredFavorites.removeIf(book -> !book.getGenre().equals(currentGenre));
            }

            if (currentQuery != null && !currentQuery.isEmpty() && !filteredFavorites.isEmpty()) {
                filteredFavorites.removeIf(book ->
                        !book.getTitle().toLowerCase().contains(currentQuery.toLowerCase()) &&
                                !book.getAuthor().toLowerCase().contains(currentQuery.toLowerCase())
                );
            }

            binding.progressBar.setVisibility(View.GONE);

            if (filteredFavorites.isEmpty()) {
                if (!currentGenre.equals("All") || !currentQuery.isEmpty()) {
                    binding.filterEmptyView.setVisibility(View.VISIBLE);
                } else {
                    binding.emptyView.setVisibility(View.VISIBLE);
                }
                binding.rvFavs.setVisibility(View.GONE);
            } else {
                binding.emptyView.setVisibility(View.GONE);
                binding.filterEmptyView.setVisibility(View.GONE);
                binding.rvFavs.setVisibility(View.VISIBLE);
                updateAdapter(filteredFavorites);
            }
        }
    }

    private void setupRecyclerView() {
        binding.rvFavs.setLayoutManager(new LinearLayoutManager(getContext()));
    }

    private void setupSearchView() {
        binding.search.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                currentQuery = query;
                filterFavorites();
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                currentQuery = newText;
                filterFavorites();
                return false;
            }
        });

        binding.search.setOnCloseListener(() -> {
            currentQuery = "";
            filterFavorites();
            return false;
        });
    }

    private void setupSpinner() {
        List<String> genres = bookRepository.getAllGenres();

        ArrayAdapter<String> spinnerAdapter = new ArrayAdapter<>(
                requireContext(),
                android.R.layout.simple_spinner_item,
                genres
        );

        spinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        binding.spinnerGenre.setAdapter(spinnerAdapter);

        binding.spinnerGenre.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                currentGenre = parent.getItemAtPosition(position).toString();
                filterFavorites();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });
    }

    private void loadAllFavoriteBooks() {
        allFavorites = bookRepository.getLikedBooks();

        handler.postDelayed(() -> {
            if (!isAdded() || binding == null) return;

            isFirstLoad = false;

            if (allFavorites.isEmpty()) {
                binding.progressBar.setVisibility(View.GONE);
                showEmptyView(true);
            } else {
                filterFavorites();
            }
        }, 2000);
    }

    private void filterFavorites() {
        if (binding == null || !isAdded()) return;

        binding.progressBar.setVisibility(View.VISIBLE);
        binding.rvFavs.setVisibility(View.GONE);
        binding.emptyView.setVisibility(View.GONE);
        binding.filterEmptyView.setVisibility(View.GONE);

        handler.postDelayed(() -> {
            if (!isAdded() || binding == null) return;

            List<Book> filteredFavorites = new ArrayList<>();

            if (allFavorites != null && !allFavorites.isEmpty()) {
                filteredFavorites = new ArrayList<>(allFavorites);
            }

            if (!currentGenre.equals("All") && !filteredFavorites.isEmpty()) {
                filteredFavorites.removeIf(book -> !book.getGenre().equals(currentGenre));
            }

            if (currentQuery != null && !currentQuery.isEmpty() && !filteredFavorites.isEmpty()) {
                filteredFavorites.removeIf(book ->
                        !book.getTitle().toLowerCase().contains(currentQuery.toLowerCase()) &&
                                !book.getAuthor().toLowerCase().contains(currentQuery.toLowerCase())
                );
            }

            binding.progressBar.setVisibility(View.GONE);

            boolean hasFilters = !currentGenre.equals("All") || (currentQuery != null && !currentQuery.isEmpty());

            if (filteredFavorites.isEmpty() && hasFilters) {
                showFilterEmptyView(true);
            } else if (filteredFavorites.isEmpty()) {
                showEmptyView(true);
            } else {
                showEmptyView(false);
                showFilterEmptyView(false);
                updateAdapter(filteredFavorites);
                binding.rvFavs.setVisibility(View.VISIBLE);
            }
        }, 2000);
    }

    private void updateAdapter(List<Book> books) {
        if (binding == null) return;

        if (adapter == null) {
            adapter = new FavoriteAdapter(books, this);
            binding.rvFavs.setAdapter(adapter);
        } else {
            adapter.updateData(books);
        }
    }

    private void showEmptyView(boolean show) {
        if (binding == null) return;

        binding.emptyView.setVisibility(show ? View.VISIBLE : View.GONE);
        binding.rvFavs.setVisibility(show ? View.GONE : View.VISIBLE);
        if (show) {
            binding.filterEmptyView.setVisibility(View.GONE);
        }
    }

    private void showFilterEmptyView(boolean show) {
        if (binding == null) return;

        binding.filterEmptyView.setVisibility(show ? View.VISIBLE : View.GONE);
        binding.rvFavs.setVisibility(show ? View.GONE : View.VISIBLE);
        binding.emptyView.setVisibility(View.GONE);
    }

    @Override
    public void onFavoriteBookClick(Book book) {
        BookDetailFragment detailFragment = new BookDetailFragment();
        Bundle args = new Bundle();
        args.putString("book_id", book.getId());
        detailFragment.setArguments(args);

        FragmentTransaction transaction = getParentFragmentManager().beginTransaction();
        transaction.replace(R.id.fragment_container, detailFragment);
        transaction.addToBackStack(null);
        transaction.commit();
    }

    @Override
    public void onDestroyView() {
        handler.removeCallbacksAndMessages(null);
        super.onDestroyView();
        binding = null;
    }
}