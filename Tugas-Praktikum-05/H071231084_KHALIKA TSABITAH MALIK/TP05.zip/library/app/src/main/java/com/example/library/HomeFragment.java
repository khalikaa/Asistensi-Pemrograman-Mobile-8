package com.example.library;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.widget.SearchView;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.GridLayoutManager;

import com.example.library.databinding.FragmentHomeBinding;

import java.util.List;

public class HomeFragment extends Fragment implements BookAdapter.OnBookClickListener {
    private FragmentHomeBinding binding;
    private BookRepository bookRepository;
    private BookAdapter adapter;
    private List<Book> books;
    private String currentGenre = "All";
    private String currentQuery = "";
    private boolean isInitialLoad = true;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        bookRepository = BookRepository.getInstance(requireContext());
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        binding = FragmentHomeBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        binding.emptyResultView.setVisibility(View.GONE);
        binding.progressBar.setVisibility(View.GONE);

        setupRecyclerView();
        setupSearchView();
        setupSpinner();

        loadBooks();
    }

    private void setupRecyclerView() {
        binding.rvBooks.setLayoutManager(new GridLayoutManager(getContext(), 2));
    }

    private void setupSearchView() {
        binding.search.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                currentQuery = query;
                filterBooks();
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                currentQuery = newText;
                filterBooks();
                return false;
            }
        });

        binding.search.setOnCloseListener(() -> {
            currentQuery = "";
            filterBooks();
            return false;
        });
    }

    private void setupSpinner() {
        List<String> genres = bookRepository.getAllGenres();

        ArrayAdapter<String> spinnerAdapter = new ArrayAdapter<>(
                requireContext(),
                android.R.layout.simple_spinner_item,
                genres
        );

        spinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        binding.spinnerGenre.setAdapter(spinnerAdapter);

        binding.spinnerGenre.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                currentGenre = parent.getItemAtPosition(position).toString();
                if (!isInitialLoad) {
                    filterBooks();
                }
                isInitialLoad = false;
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });
    }

    private void loadBooks() {
        books = bookRepository.getAllBooks();
        adapter = new BookAdapter(books, this);
        binding.rvBooks.setAdapter(adapter);

        if (books.isEmpty()) {
            binding.emptyResultView.setVisibility(View.VISIBLE);
            binding.rvBooks.setVisibility(View.GONE);
        } else {
            binding.emptyResultView.setVisibility(View.GONE);
            binding.rvBooks.setVisibility(View.VISIBLE);
        }
    }

    private void filterBooks() {
        binding.progressBar.setVisibility(View.VISIBLE);
        binding.rvBooks.setVisibility(View.GONE);
        binding.emptyResultView.setVisibility(View.GONE);

        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            List<Book> filteredBooks;
            if (currentGenre.equals("All")) {
                filteredBooks = bookRepository.getAllBooks();
            } else {
                filteredBooks = bookRepository.getBooksByGenre(currentGenre);
            }

            if (currentQuery != null && !currentQuery.isEmpty()) {
                filteredBooks = bookRepository.searchBooks(currentQuery);

                if (!currentGenre.equals("All")) {
                    filteredBooks.removeIf(book -> !book.getGenre().equals(currentGenre));
                }
            }

            adapter = new BookAdapter(filteredBooks, this);
            binding.rvBooks.setAdapter(adapter);

            binding.progressBar.setVisibility(View.GONE);

            if (filteredBooks.isEmpty()) {
                binding.emptyResultView.setVisibility(View.VISIBLE);
                binding.rvBooks.setVisibility(View.GONE);
            } else {
                binding.emptyResultView.setVisibility(View.GONE);
                binding.rvBooks.setVisibility(View.VISIBLE);
            }
        }, 2000);
    }

    @Override
    public void onBookClick(Book book) {
        BookDetailFragment detailFragment = new BookDetailFragment();
        Bundle args = new Bundle();
        args.putString("book_id", book.getId());
        detailFragment.setArguments(args);

        FragmentTransaction transaction = getParentFragmentManager().beginTransaction();
        transaction.replace(R.id.fragment_container, detailFragment);
        transaction.addToBackStack(null);
        transaction.commit();
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}