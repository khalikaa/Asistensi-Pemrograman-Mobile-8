package com.example.library;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.library.databinding.FavItemBinding;

import java.util.List;

public class FavoriteAdapter extends RecyclerView.Adapter<FavoriteAdapter.ViewHolder> {

    private List<Book> favBooks;
    private OnFavoriteBookListener listener;

    public interface OnFavoriteBookListener {
        void onFavoriteBookClick(Book book);
    }

    public FavoriteAdapter(List<Book> favBooks, OnFavoriteBookListener listener) {
        this.favBooks = favBooks;
        this.listener = listener;
    }

    @NonNull
    @Override
    public FavoriteAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        FavItemBinding binding = FavItemBinding.inflate(inflater, parent, false);
        return new ViewHolder(binding);
    }

    @Override
    public void onBindViewHolder(@NonNull FavoriteAdapter.ViewHolder holder, int position) {
        Book book = favBooks.get(position);

        holder.binding.tvTitle.setText(book.getTitle());
        holder.binding.tvAuthor.setText(book.getAuthor());
        holder.binding.tvGenre.setText(book.getGenre());
        holder.binding.bookCover.setImageURI(book.getCoverUri());
        holder.binding.tvRating.setText("⭐ " + String.format("%.1f", book.getRating()));

        holder.itemView.setOnClickListener(v -> {
            if (listener != null) {
                listener.onFavoriteBookClick(book);
            }
        });
    }

    @Override
    public int getItemCount() {
        return favBooks.size();
    }

    public void updateData(List<Book> newFavorites) {
        this.favBooks = newFavorites;
        notifyDataSetChanged();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        private FavItemBinding binding;

        public ViewHolder(@NonNull FavItemBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }
    }
}