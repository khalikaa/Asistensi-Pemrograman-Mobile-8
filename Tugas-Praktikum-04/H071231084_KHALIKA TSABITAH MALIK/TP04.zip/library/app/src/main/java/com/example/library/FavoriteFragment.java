package com.example.library;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.widget.SearchView;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.example.library.databinding.FragmentFavoritesBinding;

import java.util.ArrayList;
import java.util.List;

public class FavoriteFragment extends Fragment implements FavoriteAdapter.OnFavoriteBookListener {

    private FragmentFavoritesBinding binding;
    private BookRepository bookRepository;
    private FavoriteAdapter adapter;
    private List<Book> allFavorites;
    private String currentGenre = "All";
    private String currentQuery = "";

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        bookRepository = BookRepository.getInstance(requireContext());
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        binding = FragmentFavoritesBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        setupRecyclerView();
        setupSearchView();
        setupSpinner();

        loadAllFavoriteBooks();
    }

    private void setupRecyclerView() {
        binding.rvFavs.setLayoutManager(new LinearLayoutManager(getContext()));
    }

    private void setupSearchView() {
        binding.search.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                currentQuery = query;
                filterFavorites();
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                currentQuery = newText;
                filterFavorites();
                return false;
            }
        });

        binding.search.setOnCloseListener(() -> {
            currentQuery = "";
            filterFavorites();
            return false;
        });
    }

    private void setupSpinner() {
        List<String> genres = bookRepository.getAllGenres();

        ArrayAdapter<String> spinnerAdapter = new ArrayAdapter<>(
                requireContext(),
                android.R.layout.simple_spinner_item,
                genres
        );

        spinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        binding.spinnerGenre.setAdapter(spinnerAdapter);

        binding.spinnerGenre.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                currentGenre = parent.getItemAtPosition(position).toString();
                filterFavorites();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });
    }

    private void loadAllFavoriteBooks() {
        allFavorites = bookRepository.getLikedBooks();

        if (allFavorites.isEmpty()) {
            showEmptyView(true);
        } else {
            filterFavorites();
        }
    }

    private void filterFavorites() {
        if (allFavorites == null || allFavorites.isEmpty()) {
            showEmptyView(true);
            return;
        }

        List<Book> filteredFavorites = new ArrayList<>(allFavorites);
        boolean hasFilters = false;

        if (!currentGenre.equals("All")) {
            hasFilters = true;
            filteredFavorites.removeIf(book -> !book.getGenre().equals(currentGenre));
        }

        if (currentQuery != null && !currentQuery.isEmpty()) {
            hasFilters = true;
            filteredFavorites.removeIf(book ->
                    !book.getTitle().toLowerCase().contains(currentQuery.toLowerCase()) &&
                            !book.getAuthor().toLowerCase().contains(currentQuery.toLowerCase())
            );
        }

        if (filteredFavorites.isEmpty() && hasFilters) {
            showFilterEmptyView(true);
        } else if (filteredFavorites.isEmpty()) {
            showEmptyView(true);
        } else {
            showEmptyView(false);
            showFilterEmptyView(false);
            updateAdapter(filteredFavorites);
        }
    }

    private void updateAdapter(List<Book> books) {
        if (adapter == null) {
            adapter = new FavoriteAdapter(books, this);
            binding.rvFavs.setAdapter(adapter);
        } else {
            adapter.updateData(books);
        }
    }

    private void showEmptyView(boolean show) {
        binding.emptyView.setVisibility(show ? View.VISIBLE : View.GONE);
        binding.rvFavs.setVisibility(show ? View.GONE : View.VISIBLE);
        if (show) {
            binding.filterEmptyView.setVisibility(View.GONE);
        }
    }

    private void showFilterEmptyView(boolean show) {
        binding.filterEmptyView.setVisibility(show ? View.VISIBLE : View.GONE);
        binding.rvFavs.setVisibility(show ? View.GONE : View.VISIBLE);
        binding.emptyView.setVisibility(View.GONE);
    }

    @Override
    public void onFavoriteBookClick(Book book) {
        BookDetailFragment detailFragment = new BookDetailFragment();
        Bundle args = new Bundle();
        args.putString("book_id", book.getId());
        detailFragment.setArguments(args);

        FragmentTransaction transaction = getParentFragmentManager().beginTransaction();
        transaction.replace(R.id.fragment_container, detailFragment);
        transaction.addToBackStack(null);
        transaction.commit();
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

}