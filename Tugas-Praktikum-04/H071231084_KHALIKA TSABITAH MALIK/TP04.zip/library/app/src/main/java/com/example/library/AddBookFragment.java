package com.example.library;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;

import com.example.library.databinding.FragmentAddBookBinding;

import java.util.Calendar;
import java.util.List;
import java.util.UUID;

public class AddBookFragment extends Fragment {

    private FragmentAddBookBinding binding;
    private BookRepository bookRepository;
    private Uri selectedImageUri = null;
    private boolean isNewGenre = false;

    private final ActivityResultLauncher<Intent> imagePickerLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            result -> {
                if (result.getResultCode() == Activity.RESULT_OK && result.getData() != null) {
                    selectedImageUri = result.getData().getData();
                    binding.ivBookCover.setImageURI(selectedImageUri);
                    binding.ivBookCover.setVisibility(View.VISIBLE);
                    binding.btnAddCover.setText("Change Cover");
                }
            });

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        bookRepository = BookRepository.getInstance(requireContext());
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        binding = FragmentAddBookBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        setupGenreSpinner();
        setupListeners();
        setupYearPicker();
        setupRatingBar();

        binding.ivBookCover.setImageResource(R.drawable.default_book_cover);
        binding.ivBookCover.setVisibility(View.VISIBLE);
    }

    private void setupGenreSpinner() {
        List<String> genres = bookRepository.getAllGenres();
        genres.remove("All");
        genres.add("+ Add new genre");

        ArrayAdapter<String> adapter = new ArrayAdapter<>(
                requireContext(),
                android.R.layout.simple_spinner_item,
                genres);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        binding.spinnerGenre.setAdapter(adapter);

        binding.spinnerGenre.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(android.widget.AdapterView<?> parent, View view, int position, long id) {
                String selectedGenre = parent.getItemAtPosition(position).toString();
                if (selectedGenre.equals("+ Add new genre")) {
                    binding.newGenreLayout.setVisibility(View.VISIBLE);
                    isNewGenre = true;
                } else {
                    binding.newGenreLayout.setVisibility(View.GONE);
                    isNewGenre = false;
                }
            }

            @Override
            public void onNothingSelected(android.widget.AdapterView<?> parent) {
                binding.newGenreLayout.setVisibility(View.GONE);
                isNewGenre = false;
            }
        });
    }

    private void setupListeners() {
        binding.btnAddCover.setOnClickListener(v -> openImagePicker());

        binding.btnSaveBook.setOnClickListener(v -> validateAndSaveBook());
    }

    private void setupYearPicker() {
        int currentYear = Calendar.getInstance().get(Calendar.YEAR);
        binding.yearPicker.setMinValue(2000);
        binding.yearPicker.setMaxValue(currentYear);
        binding.yearPicker.setValue(currentYear);
    }

    private void setupRatingBar() {
        binding.ratingBar.setRating(3.5f);
    }

    private void openImagePicker() {
        Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        imagePickerLauncher.launch(intent);
    }

    private void validateAndSaveBook() {
        String title = binding.etTitle.getText().toString().trim();
        String author = binding.etAuthor.getText().toString().trim();
        String blurb = binding.etBlurb.getText().toString().trim();
        int year = binding.yearPicker.getValue();
        float rating = binding.ratingBar.getRating();

         if (title.isEmpty()) {
            Toast.makeText(requireContext(), "Title cannot be empty", Toast.LENGTH_SHORT).show();
            return;
        }

        if (author.isEmpty()) {
            Toast.makeText(requireContext(), "Author cannot be empty", Toast.LENGTH_SHORT).show();
            return;
        }

        if (blurb.isEmpty()) {
            Toast.makeText(requireContext(), "Description cannot be empty", Toast.LENGTH_SHORT).show();
            return;
        }

        if (selectedImageUri == null) {
            Toast.makeText(requireContext(), "Please select a book cover", Toast.LENGTH_SHORT).show();
            return;
        }

        String genre;
        if (isNewGenre) {
            genre = binding.etNewGenre.getText().toString().trim();
            if (genre.isEmpty()) {
                Toast.makeText(requireContext(), "Please input a new genre", Toast.LENGTH_SHORT).show();
                return;
            }
            bookRepository.addGenre(genre);
        } else {
            int selectedPosition = binding.spinnerGenre.getSelectedItemPosition();
            if (selectedPosition == binding.spinnerGenre.getCount() - 1) {
                Toast.makeText(requireContext(), "Please select a genre or add a new one", Toast.LENGTH_SHORT).show();
                return;
            }
            genre = binding.spinnerGenre.getSelectedItem().toString();
        }

        String bookId = UUID.randomUUID().toString();

        Book newBook = new Book(
                bookId,
                title,
                author,
                year,
                blurb,
                selectedImageUri,
                false,
                genre,
                rating
        );

        bookRepository.addBook(newBook);

        Toast.makeText(requireContext(), "Book added successfully!", Toast.LENGTH_SHORT).show();

        navigateToHome();
    }

    private void navigateToHome() {
        if (getActivity() != null && getActivity() instanceof MainActivity) {
            MainActivity mainActivity = (MainActivity) getActivity();

            mainActivity.binding.btnHome.performClick();
        }
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}