package com.example.tp02;

import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import com.google.android.material.imageview.ShapeableImageView;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

public class EditActivity extends AppCompatActivity {

    private static final int PICK_IMAGE = 1;
    private ImageButton backBtn;
    private Button saveBtn;
    private EditText  editName, editUsn;
    private ShapeableImageView avaImage;
    private TextView changeAva;
    private Uri selectedImageUri;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_edit);

        backBtn = findViewById(R.id.btnBack);
        saveBtn = findViewById(R.id.btnSave);
        editName = findViewById(R.id.editName);
        editUsn = findViewById(R.id.editUsername);
        avaImage = findViewById(R.id.avaImage);
        changeAva = findViewById(R.id.changeAva);

        SharedPreferences prefs = getSharedPreferences("user_profile", MODE_PRIVATE);
        String name = prefs.getString("name", "Guest");
        String username = prefs.getString("username", "guest");

        editName.setText(name);
        editUsn.setText(username);

        String imagePath = prefs.getString("imagePath", null);

        if (imagePath != null) {
            avaImage.setImageURI(Uri.fromFile(new File(imagePath)));
        } else {
            avaImage.setImageResource(R.drawable.ava);
        }
        backBtn.setOnClickListener(v -> {
            Intent intent = new Intent(EditActivity.this, SettingsActivity.class);
            startActivity(intent);
        });

        saveBtn.setOnClickListener(v -> {
            String nameInput = editName.getText().toString();
            String usnInput = editUsn.getText().toString();

            SharedPreferences.Editor editor = prefs.edit();
            if (!nameInput.isEmpty()) {
                editor.putString("name", nameInput);
            }
            if (!usnInput.isEmpty()) {
                editor.putString("username", usnInput);
            }
            if (selectedImageUri != null) {
                editor.putString("imagePath", selectedImageUri.getPath());
            }
            editor.apply();

            if(!nameInput.isEmpty() && !usnInput.isEmpty() && selectedImageUri != null) {
                Intent intent = new Intent(EditActivity.this, MainActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP); // clear stack biar nggak numpuk
                startActivity(intent);
                finish();
            } else {
                if (nameInput.isEmpty()) {
                    Toast.makeText(EditActivity.this,"Nama Tidak Boleh Kosong", Toast.LENGTH_SHORT).show();
                }

                if (usnInput.isEmpty()) {
                    Toast.makeText(EditActivity.this,"Username Tidak Boleh Kosong", Toast.LENGTH_SHORT).show();
                }
            }
        });

        changeAva.setOnClickListener(v -> {
            Intent intent = new Intent(Intent.ACTION_PICK);
            intent.setType("image/*");
            startActivityForResult(intent, PICK_IMAGE);
        });

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.edit), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == PICK_IMAGE && resultCode == RESULT_OK && data != null) {
            selectedImageUri = data.getData();
            avaImage.setImageURI(selectedImageUri); // tampilkan preview

            String savedPath = saveImageToInternalStorage(selectedImageUri);
            if (savedPath != null) {
                selectedImageUri = Uri.fromFile(new File(savedPath)); // update Uri jadi file lokal
            }
        }
    }

    private String saveImageToInternalStorage(Uri uri) {
        try {
            InputStream inputStream = getContentResolver().openInputStream(uri);
            File file = new File(getFilesDir(), "avatar.jpg");
            OutputStream outputStream = new FileOutputStream(file);

            byte[] buffer = new byte[1024];
            int length;
            while ((length = inputStream.read(buffer)) > 0) {
                outputStream.write(buffer, 0, length);
            }

            outputStream.close();
            inputStream.close();

            return file.getAbsolutePath(); // ini yang nanti disimpan
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }


}