package com.example.tp02;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.net.Uri;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import java.io.File;

public class MainActivity extends AppCompatActivity {

    private ImageButton btnSetting;
    private TextView dis_name, dis_usn;
    private ImageView ava;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        btnSetting = findViewById(R.id.btnSet);
        dis_name = findViewById(R.id.nickname);
        dis_usn = findViewById(R.id.usn);
        ava = findViewById(R.id.ava);

        SharedPreferences prefs = getSharedPreferences("user_profile", MODE_PRIVATE);

        String name = prefs.getString("name", "Guest");
        String username = prefs.getString("username", "guest");
        String imagePath = prefs.getString("imagePath", null);

        if (imagePath != null) {
            ava.setImageURI(Uri.fromFile(new File(imagePath)));
        } else {
            ava.setImageResource(R.drawable.ava);
        }

        dis_name.setText(name);
        dis_usn.setText("@" + username);

        btnSetting.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, SettingsActivity.class);
            startActivity(intent);
        });

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }

    @Override
    protected void onResume() {
        super.onResume();

        SharedPreferences prefs = getSharedPreferences("user_profile", MODE_PRIVATE);
        String name = prefs.getString("name", "Guest");
        String username = prefs.getString("username", "guest");

        dis_name.setText(name);
        dis_usn.setText("@" + username);
        String imagePath = prefs.getString("imagePath", null);

        if (imagePath != null) {
            ava.setImageURI(Uri.fromFile(new File(imagePath)));
        } else {
            ava.setImageResource(R.drawable.ava);
        }
    }

}