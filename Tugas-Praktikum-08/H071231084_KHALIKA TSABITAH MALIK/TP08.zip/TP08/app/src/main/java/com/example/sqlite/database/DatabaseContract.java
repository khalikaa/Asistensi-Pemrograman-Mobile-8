package com.example.sqlite.database;

import android.provider.BaseColumns;

public class DatabaseContract {
    public static String TABLE_NAME = "tasks";

    public static final class TaskColumns implements BaseColumns {
        public static String TITLE = "title";
        public static String DESCRIPTION = "description";
        public static final String CREATED_AT = "created_at";
        public static final String UPDATED_AT = "updated_at";
    }
}
