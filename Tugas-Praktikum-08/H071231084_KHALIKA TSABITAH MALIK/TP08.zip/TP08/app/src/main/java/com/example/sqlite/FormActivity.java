package com.example.sqlite;

import android.content.ContentValues;
import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;
import androidx.activity.OnBackPressedCallback;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.sqlite.database.DatabaseContract;
import com.example.sqlite.database.TaskHelper;
import com.example.sqlite.databinding.ActivityFormBinding;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class FormActivity extends AppCompatActivity {
    public static final String EXTRA_TASK = "extra_task";
    public static final int RESULT_ADD = 101;
    public static final int RESULT_UPDATE = 201;
    public static final int RESULT_DELETE = 301;
    public static final int REQUEST_UPDATE = 200;

    private TaskHelper taskHelper;
    private Task task;
    private boolean isEdit = false;
    private String initialTitle, initialDescription;
    private ActivityFormBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityFormBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        ViewCompat.setOnApplyWindowInsetsListener(binding.getRoot(), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        taskHelper = TaskHelper.getInstance(getApplicationContext());
        taskHelper.open();

        task = getIntent().getParcelableExtra(EXTRA_TASK);
        if (task != null) {
            isEdit = true;
        } else {
            task = new Task();
        }

        String formTitle;
        String btnTitle;

        if (isEdit) {
            formTitle = "Edit Task";
            btnTitle = "Save Changes";
            initialTitle = task.getTitle();
            initialDescription = task.getDescription();

            binding.etTitle.setText(task.getTitle());
            binding.etDescription.setText(task.getDescription());

            binding.btnDelete.setVisibility(View.VISIBLE);
        } else {
            formTitle = "Add New Task";
            btnTitle = "Save";
        }

        binding.btnSave.setText(btnTitle);
        binding.tvFormTitle.setText(formTitle);

        binding.btnSave.setOnClickListener(v -> saveTask());
        binding.btnDelete.setOnClickListener(v -> deleteTask());

        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                if (isFormChanged()) {
                    new AlertDialog.Builder(FormActivity.this)
                            .setTitle("Exit without saving?")
                            .setMessage("Are you sure you want to exit? Changes will not be saved.")
                            .setPositiveButton("Yes", (dialog, which) -> {
                                this.setEnabled(false);
                                getOnBackPressedDispatcher().onBackPressed();
                            })
                            .setNegativeButton("Cancel", null)
                            .show();
                } else {
                    new AlertDialog.Builder(FormActivity.this)
                            .setTitle("Exit without editing data?")
                            .setMessage("Are you sure you want to exit without editing data?")
                            .setPositiveButton("Yes", (dialog, which) -> {
                                this.setEnabled(false);
                                getOnBackPressedDispatcher().onBackPressed();
                            })
                            .setNegativeButton("Cancel", null)
                            .show();
                }
            }
        });
    }

    private void saveTask() {
        String title = binding.etTitle.getText().toString().trim();
        String description = binding.etDescription.getText().toString().trim();
        String currentDate = new SimpleDateFormat("dd MMMM, yyyy HH:mm", Locale.getDefault()).format(new Date());

        if (title.isEmpty()) {
            binding.etTitle.setError("Field can not be blank");
            return;
        }

        if (description.isEmpty()) {
            binding.etDescription.setError("Field can not be blank");
            return;
        }

        task.setTitle(title);
        task.setDescription(description);

        Intent intent = new Intent();

        ContentValues values = new ContentValues();
        values.put(DatabaseContract.TaskColumns.TITLE, title);
        values.put(DatabaseContract.TaskColumns.DESCRIPTION, description);

        if (isEdit) {
            task.setUpdatedAt(currentDate);
            values.put(DatabaseContract.TaskColumns.UPDATED_AT, currentDate);
            long result = taskHelper.update(String.valueOf(task.getId()), values);
            if (result > 0) {
                setResult(RESULT_UPDATE, intent);
                intent.putExtra(EXTRA_TASK, task);
                finish();
            } else {
                Toast.makeText(FormActivity.this, "Failed to update data", Toast.LENGTH_SHORT).show();
            }
        } else {
            task.setCreatedAt(currentDate);
            task.setUpdatedAt(currentDate);
            values.put(DatabaseContract.TaskColumns.CREATED_AT, currentDate);
            values.put(DatabaseContract.TaskColumns.UPDATED_AT, currentDate);
            long result = taskHelper.insert(values);
            if (result > 0) {
                task.setId((int) result);
                setResult(RESULT_ADD, intent);
                intent.putExtra(EXTRA_TASK, task);
                finish();
            } else {
                Toast.makeText(FormActivity.this, "Failed to add data", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void deleteTask() {
        new AlertDialog.Builder(this)
                .setTitle("⚠ Delete Task")
                .setMessage("Are you sure you want to delete this task?")
                .setPositiveButton("Delete", (dialog, which) -> {
                    if (task != null && task.getId() > 0) {
                        int result = taskHelper.deleteById(String.valueOf(task.getId()));
                        if (result > 0) {
                            setResult(RESULT_DELETE, new Intent());
                            finish();
                        } else {
                            Toast.makeText(FormActivity.this, "Failed to delete data", Toast.LENGTH_SHORT).show();
                        }
                    } else {
                        Toast.makeText(FormActivity.this, "Failed to delete data", Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton("Cancel", null) // Do nothing on cancel
                .show();
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (taskHelper != null) {
            taskHelper.close();
        }
    }

    private boolean isFormChanged() {
        String currentTitle = binding.etTitle.getText().toString().trim();
        String currentDescription = binding.etDescription.getText().toString().trim();

        if (isEdit) {
            return !currentTitle.equals(initialTitle) || !currentDescription.equals(initialDescription);
        } else {
            return !currentTitle.isEmpty() || !currentDescription.isEmpty();
        }
    }
}