package com.example.sqlite;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SearchView;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.example.sqlite.database.MappingHelper;
import com.example.sqlite.database.TaskHelper;
import com.example.sqlite.databinding.ActivityMainBinding;

import java.util.ArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends AppCompatActivity {
    private TaskAdapter adapter;
    private TaskHelper taskHelper;
    private ActivityMainBinding binding;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private final Handler handler = new Handler(Looper.getMainLooper());


    private final int REQUEST_ADD = 100;
    private final int REQUEST_UPDATE = 200;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        ViewCompat.setOnApplyWindowInsetsListener(binding.getRoot(), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle("Tasks List");
        }

        binding.rvTasks.setLayoutManager(new LinearLayoutManager(this));
        adapter = new TaskAdapter(this);
        binding.rvTasks.setAdapter(adapter);

        taskHelper = TaskHelper.getInstance(getApplicationContext());

        binding.fabAdd.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, FormActivity.class);
            startActivityForResult(intent, REQUEST_ADD);
        });

        loadTasks();

        binding.search.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String title) {
                searchTasks(title);
                return true;
            }

            @Override
            public boolean onQueryTextChange(String title) {
                searchTasks(title);
                return true;
            }
        });
    }

    private void loadTasks() {
        executor.execute(() -> {
            taskHelper.open();
            Cursor cursor = taskHelper.queryAll();
            ArrayList<Task> tasks = MappingHelper.mapCursorToArrayList(cursor);
            cursor.close();

            handler.post(() -> {
                if (tasks.size() > 0) {
                    adapter.setTasks(tasks);
                    binding.noData.setVisibility(View.GONE);
                } else {
                    adapter.setTasks(new ArrayList<>());
                    binding.noData.setVisibility(View.VISIBLE);
                }
            });
        });
    }

    private void searchTasks(String title) {
        executor.execute(() -> {
            try {
                taskHelper.open();
                Cursor cursor = taskHelper.querybByTitle(title);
                ArrayList<Task> result = MappingHelper.mapCursorToArrayList(cursor);
                cursor.close();

                handler.post(() -> {
                    if (result.size() > 0) {
                        adapter.setTasks(result);
                        binding.noData.setVisibility(View.GONE);
                    } else {
                        adapter.setTasks(new ArrayList<>());
                        binding.noData.setText("There is no matching result");
                        binding.noData.setVisibility(View.VISIBLE);
                    }
                });
            } catch (Exception e) {
                e.printStackTrace();
                handler.post(() -> {
                    Toast.makeText(MainActivity.this, "Search error: " + e.getMessage(),
                            Toast.LENGTH_SHORT).show();
                });
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REQUEST_ADD) {
            if (resultCode == FormActivity.RESULT_ADD) {
                showToast("Task added successfully");
                loadTasks();
            }
        } else if (requestCode == REQUEST_UPDATE) {
            if (resultCode == FormActivity.RESULT_UPDATE) {
                showToast("Task updated successfully");
                loadTasks();
            } else if (resultCode == FormActivity.RESULT_DELETE) {
                showToast("Task deleted successfully");
                loadTasks();
            }
        }
    }

    private void showToast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (taskHelper != null) {
            taskHelper.close();
        }
    }
}