package com.example.sqlite.database;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class DatabaseHelper extends SQLiteOpenHelper {
    public static String DATABASE_NAME = "tasks.db";
    private static final int DATABASE_VERSION = 2;

    private final String SQL_CREATE_TABLE_STUDENT =
            String.format("CREATE TABLE %s " +
                    "(%s INTEGER PRIMARY KEY AUTOINCREMENT," +
                    " %s TEXT NOT NULL," +
                    " %s TEXT NOT NULL," +
                    " %s TEXT NOT NULL," +
                    " %s TEXT )",
                    DatabaseContract.TABLE_NAME,
                    DatabaseContract.TaskColumns._ID ,
                    DatabaseContract.TaskColumns.TITLE,
                    DatabaseContract.TaskColumns.DESCRIPTION,
                    DatabaseContract.TaskColumns.CREATED_AT,
                    DatabaseContract.TaskColumns.UPDATED_AT);

    public DatabaseHelper(@Nullable Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(SQL_CREATE_TABLE_STUDENT);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + DatabaseContract.TABLE_NAME);
        onCreate(db);
    }
}
