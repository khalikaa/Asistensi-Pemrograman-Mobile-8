package com.example.sqlite;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.sqlite.databinding.ItemTaskBinding;

import java.util.ArrayList;

public class TaskAdapter extends RecyclerView.Adapter<TaskAdapter.TaskViewHolder> {
    private final ArrayList<Task> tasks = new ArrayList<>();
    private final Activity activity;

    public TaskAdapter(Activity activity) {
        this.activity = activity;
    }

    public void setTasks(ArrayList<Task> tasks) {
        this.tasks.clear();
        if (tasks.size() > 0) {
            this.tasks.addAll(tasks);
        }
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public TaskAdapter.TaskViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        ItemTaskBinding binding = ItemTaskBinding.inflate(inflater, parent, false);
        return new TaskViewHolder(binding);
    }

    @Override
    public void onBindViewHolder(@NonNull TaskAdapter.TaskViewHolder holder, int position) {
        holder.bind(tasks.get(position));
    }

    @Override
    public int getItemCount() {
        return tasks.size();
    }

    public class TaskViewHolder extends RecyclerView.ViewHolder {
        final ItemTaskBinding binding;

        public TaskViewHolder(ItemTaskBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }

        @SuppressLint("SetTextI18n")
        public void bind(Task task) {
            binding.tvItemTitle.setText(task.getTitle());
            binding.tvItemDescription.setText(task.getDescription());
            binding.tvCreatedDate.setText("Created at " + task.getCreatedAt());
            binding.tvEditedDate.setText("Last Updated at " + task.getUpdatedAt());

            binding.cardView.setOnClickListener(v -> {
              Intent intent = new Intent(activity, FormActivity.class);
              intent.putExtra(FormActivity.EXTRA_TASK, task);
              activity.startActivityForResult(intent, FormActivity.REQUEST_UPDATE);
            });
        }
    }
}
