package com.example.sqlite.database;

import android.database.Cursor;

import com.example.sqlite.Task;

import java.util.ArrayList;

public class MappingHelper {
    public static ArrayList<Task> mapCursorToArrayList(Cursor tasksCursor) {
        ArrayList<Task> tasks = new ArrayList<>();
        while (tasksCursor.moveToNext()) {
            int id = tasksCursor.getInt(tasksCursor.getColumnIndexOrThrow(DatabaseContract.TaskColumns._ID));
            Task task;
            String title = tasksCursor.getString(tasksCursor.getColumnIndexOrThrow(DatabaseContract.TaskColumns.TITLE));
            String description = tasksCursor.getString(tasksCursor.getColumnIndexOrThrow(DatabaseContract.TaskColumns.DESCRIPTION));
            String createdAt = tasksCursor.getString(tasksCursor.getColumnIndexOrThrow(DatabaseContract.TaskColumns.CREATED_AT));
            String updatedAt = tasksCursor.getString(tasksCursor.getColumnIndexOrThrow(DatabaseContract.TaskColumns.UPDATED_AT));
            task = new Task(id, title, description, createdAt, updatedAt);
            tasks.add(task);
        }
        return tasks;
    }
}