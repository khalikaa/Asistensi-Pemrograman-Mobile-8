package com.example.tp6.ui;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.tp6.R;
import com.example.tp6.data.response.User;
import com.example.tp6.databinding.ButtonLebihBinding;
import com.example.tp6.databinding.KarakterItemBinding;

import java.util.List;

public class UserAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    private static final int VIEW_TYPE_USER = 1;
    private static final int VIEW_TYPE_LOAD_MORE = 2;

    private List<User> userList;
    private OnLoadMoreClickListener loadMoreClickListener;
    private boolean showLoadMore = false;
    private OnUserClickListener onUserClickListener;

    public UserAdapter(List<User> userList) {
        this.userList = userList;
    }

    public void setShowLoadMore(boolean show) {
        showLoadMore = show;
        notifyDataSetChanged();
    }

    public void addMoreUsers(List<User> newUsers) {
        int start = userList.size();
        userList.addAll(newUsers);
        notifyItemRangeInserted(start, newUsers.size());
    }

    public void setOnLoadMoreClickListener(OnLoadMoreClickListener listener) {
        this.loadMoreClickListener = listener;
    }

    public void setOnUserClickListener(OnUserClickListener listener) {
        this.onUserClickListener = listener;
    }

    @Override
    public int getItemViewType(int position) {
        if (showLoadMore && position == userList.size()) {
            return VIEW_TYPE_LOAD_MORE;
        }
        return VIEW_TYPE_USER;
    }

    @Override
    public int getItemCount() {
        return showLoadMore ? userList.size() + 1 : userList.size();
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        if (viewType == VIEW_TYPE_LOAD_MORE) {
            ButtonLebihBinding binding = ButtonLebihBinding.inflate(inflater, parent, false);
            return new LoadMoreViewHolder(binding);
        } else {
            KarakterItemBinding binding = KarakterItemBinding.inflate(inflater, parent, false);
            return new UserViewHolder(binding);
        }
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        if (holder instanceof UserViewHolder) {
            User user = userList.get(position);
            ((UserViewHolder) holder).bind(user);

            holder.itemView.setOnClickListener(v -> {
                if (onUserClickListener != null) {
                    onUserClickListener.onUserClick(user);
                }
            });
        } else if (holder instanceof LoadMoreViewHolder) {
            ((LoadMoreViewHolder) holder).bind();
        }
    }


    public interface OnUserClickListener {
        void onUserClick(User user);
    }

    public class UserViewHolder extends RecyclerView.ViewHolder {
        private final KarakterItemBinding binding;

        public UserViewHolder(@NonNull KarakterItemBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }

        public void bind(User user) {
            binding.name.setText(user.getName());
            binding.species.setText(user.getSpecies());
            Glide.with(binding.getRoot().getContext()).load(user.getImage()).into(binding.image);
        }
    }

    public void clearUsers() {
        userList.clear();
        notifyDataSetChanged();
    }

    public class LoadMoreViewHolder extends RecyclerView.ViewHolder {
        private final ButtonLebihBinding binding;

        public LoadMoreViewHolder (@NonNull ButtonLebihBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }

        public void bind() {
            binding.button.setOnClickListener(v -> {
                if (loadMoreClickListener != null) {
                    loadMoreClickListener.onLoadMoreClick();
                }
            });
        }
    }

    public interface OnLoadMoreClickListener {
        void onLoadMoreClick();
    }
}