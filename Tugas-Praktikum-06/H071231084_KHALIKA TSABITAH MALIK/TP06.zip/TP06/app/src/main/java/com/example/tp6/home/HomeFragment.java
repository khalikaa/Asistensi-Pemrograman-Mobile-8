package com.example.tp6.home;

import android.os.Bundle;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.example.tp6.R;
import com.example.tp6.data.network.ApiConfig;
import com.example.tp6.data.network.ApiService;
import com.example.tp6.data.network.NetworkUtil;
import com.example.tp6.data.response.User;
import com.example.tp6.data.response.UserResponse;
import com.example.tp6.databinding.FragmentHomeBinding;
import com.example.tp6.ui.UserAdapter;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import androidx.fragment.app.FragmentTransaction;

public class HomeFragment extends Fragment {
    private FragmentHomeBinding binding;
    private UserAdapter userAdapter;
    private int currentPage = 1;
    private boolean isLoading = false;
    private final List<User> cachedUsers = new ArrayList<>();
    private int clickedItemPosition = 0;
    private LinearLayoutManager layoutManager;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        binding = FragmentHomeBinding.inflate(inflater, container, false);

        layoutManager = new LinearLayoutManager(getContext());
        binding.userRecycler.setLayoutManager(layoutManager);

        userAdapter = new UserAdapter(new ArrayList<>(cachedUsers));
        binding.userRecycler.setAdapter(userAdapter);

        userAdapter.setOnUserClickListener(user -> {
            for (int i = 0; i < cachedUsers.size(); i++) {
                if (cachedUsers.get(i).getId() == user.getId()) {
                    clickedItemPosition = i;
                    break;
                }
            }

            int characterId = user.getId();
            DetailFragment detailFragment = DetailFragment.newInstance(characterId);
            FragmentTransaction transaction = getParentFragmentManager().beginTransaction();
            transaction.replace(R.id.fragment_container, detailFragment);
            transaction.addToBackStack(null);
            transaction.commit();
        });

        userAdapter.setOnLoadMoreClickListener(() -> {
            if (!isLoading && NetworkUtil.isNetworkAvailable(getContext())) {
                currentPage++;
                loadUsers(currentPage);
            }
        });

        binding.refresh.setOnClickListener(v -> {
            binding.pb.setVisibility(View.VISIBLE);
            binding.errorLayout.setVisibility(View.GONE);
            new Handler().postDelayed(() -> {
                binding.pb.setVisibility(View.GONE);
                checkNetworkAndLoadIfNeeded();
            }, 2000);
        });

        return binding.getRoot();
    }

    @Override
    public void onResume() {
        super.onResume();
        if (cachedUsers.isEmpty()) {
            checkNetworkAndLoadIfNeeded();
        } else {
            binding.errorLayout.setVisibility(View.GONE);
            binding.userRecycler.setVisibility(View.VISIBLE);
            binding.pb.setVisibility(View.GONE);

            userAdapter.clearUsers();
            userAdapter.addMoreUsers(cachedUsers);
            userAdapter.setShowLoadMore(true);

            layoutManager.scrollToPosition(clickedItemPosition);
        }
    }

    private void checkNetworkAndLoadIfNeeded() {
        if (!NetworkUtil.isNetworkAvailable(getContext())) {
            if (!cachedUsers.isEmpty()) {
                binding.errorLayout.setVisibility(View.GONE);
                binding.userRecycler.setVisibility(View.VISIBLE);
                binding.pb.setVisibility(View.GONE);

                userAdapter.clearUsers();
                userAdapter.addMoreUsers(cachedUsers);
                userAdapter.setShowLoadMore(false);

                layoutManager.scrollToPosition(clickedItemPosition);
            } else {
                binding.errorLayout.setVisibility(View.VISIBLE);
                binding.userRecycler.setVisibility(View.GONE);
                binding.pb.setVisibility(View.GONE);
            }
        } else {
            binding.errorLayout.setVisibility(View.GONE);
            binding.userRecycler.setVisibility(View.VISIBLE);

            if (userAdapter.getItemCount() == 0) {
                binding.pb.setVisibility(View.VISIBLE);
                // If we don't have any data, start from page 1
                currentPage = 1;
                loadUsers(currentPage);
            }
        }
    }

    private void loadUsers(int page) {
        if (!NetworkUtil.isNetworkAvailable(getContext())) {
            binding.errorLayout.setVisibility(View.VISIBLE);
            binding.userRecycler.setVisibility(View.GONE);
            binding.pb.setVisibility(View.GONE);
            isLoading = false;
            return;
        }

        isLoading = true;
        binding.pb.setVisibility(View.VISIBLE);

        ApiService apiService = ApiConfig.getClient().create(ApiService.class);
        apiService.getCharacterData(page).enqueue(new Callback<UserResponse>() {
            @Override
            public void onResponse(Call<UserResponse> call, Response<UserResponse> response) {
                isLoading = false;
                binding.pb.setVisibility(View.GONE);

                if (response.isSuccessful() && response.body() != null) {
                    List<User> newUsers = response.body().getResults();
                    if (page == 1) {
                        userAdapter.clearUsers();
                        cachedUsers.clear();
                        clickedItemPosition = 0;
                    }

                    userAdapter.addMoreUsers(newUsers);
                    cachedUsers.addAll(newUsers);
                    userAdapter.setShowLoadMore(!newUsers.isEmpty());
                }
            }

            @Override
            public void onFailure(Call<UserResponse> call, Throwable t) {
                isLoading = false;
                binding.pb.setVisibility(View.GONE);
                binding.errorLayout.setVisibility(View.VISIBLE);
                binding.userRecycler.setVisibility(View.GONE);
            }
        });
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}